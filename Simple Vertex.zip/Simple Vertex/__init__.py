bl_info = {
    "name": "Vertex",
    "author": "Petit & AI Collaborator",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Add > Mesh > Vertex",
    "description": "",
    "category": "Mesh",
}

import bpy
import bmesh

class MESH_OT_add_single_vertex(bpy.types.Operator):
    bl_idname = "mesh.add_vertex"
    bl_label = "Vertex"
    bl_description = "Construct a single vertex"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mesh = bpy.data.meshes.new(name="Vertex")
        obj = bpy.data.objects.new(name="Vertex", object_data=mesh)
        
        context.collection.objects.link(obj)
        obj.location = context.scene.cursor.location
        
        bm = bmesh.new()
        vert = bm.verts.new((0.0, 0.0, 0.0))
        
        vert.select = True
        bm.select_history.add(vert)
        
        bm.to_mesh(mesh)
        bm.free()
        
        mesh.update()
        if mesh.vertices:
            mesh.vertices[0].select = True 
        
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active = obj
        obj.select_set(True)
        
        return {'FINISHED'}

original_mesh_add_draw = None

def custom_menu_draw(self, context):
    layout = self.layout
    layout.operator("mesh.primitive_plane_add", text="Plane", icon='MESH_PLANE')
    layout.operator("mesh.primitive_cube_add", text="Cube", icon='MESH_CUBE')
    layout.operator(MESH_OT_add_single_vertex.bl_idname, icon='VERTEXSEL') 
    layout.operator("mesh.primitive_circle_add", text="Circle", icon='MESH_CIRCLE')
    layout.operator("mesh.primitive_uv_sphere_add", text="UV Sphere", icon='MESH_UVSPHERE')
    layout.operator("mesh.primitive_ico_sphere_add", text="Ico Sphere", icon='MESH_ICOSPHERE')
    layout.operator("mesh.primitive_cylinder_add", text="Cylinder", icon='MESH_CYLINDER')
    layout.operator("mesh.primitive_cone_add", text="Cone", icon='MESH_CONE')
    layout.operator("mesh.primitive_torus_add", text="Torus", icon='MESH_TORUS')
    layout.separator()
    layout.operator("mesh.primitive_grid_add", text="Grid", icon='MESH_GRID')
    layout.operator("mesh.primitive_monkey_add", text="Monkey", icon='MESH_MONKEY')

def register():
    global original_mesh_add_draw
    bpy.utils.register_class(MESH_OT_add_single_vertex)
    original_mesh_add_draw = bpy.types.VIEW3D_MT_mesh_add.draw
    bpy.types.VIEW3D_MT_mesh_add.draw = custom_menu_draw

def unregister():
    global original_mesh_add_draw
    if original_mesh_add_draw:
        bpy.types.VIEW3D_MT_mesh_add.draw = original_mesh_add_draw
    bpy.utils.unregister_class(MESH_OT_add_single_vertex)

if __name__ == "__main__":
    register()